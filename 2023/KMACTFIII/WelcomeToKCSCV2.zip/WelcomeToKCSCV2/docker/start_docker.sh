#!/bin/sh

docker build . -t welcometokcscv2
docker run -d --rm -p 5002:5000 -it welcometokcscv2
