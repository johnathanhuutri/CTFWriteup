Name: KMAWeb V2
Description: OMG! The website was vulnerable to a critical bug so I managed to patch it immediately. Then I implemented a back-end service to manage the front-end. I bet you can attack it if you can 😏

P/s: Install dependency `Flask` with pip3 then run `python3 run.py`

### Private
- docker: dùng để build và chạy docker trên server
- player: các file trong thư mục này được chia sẻ cho người chơi
- solution: chứa source và solve script
- flag trong file admin.flag