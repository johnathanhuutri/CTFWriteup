#!/bin/sh

gcc notanote.c -o notanote
cp notanote libc.so.6 ld-2.37.so ../player
cp notanote ../docker/share

rm notanote_patched
pwninit