#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

char *note[8];

void init()
{
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
}

void menu()
{
    puts("1. Create note");
    puts("2. Edit note");
    puts("3. View note");
    puts("4. Delete note");
    puts("5. Exit");
    printf("> ");
}

void read_str(char *buf, int32_t size)
{
    char c;
    int32_t i = 0;

    while (i<size)
    {
        read(0, &c, 1);
        if (c=='\n')
            break;
        buf[i++] = c;
    }
}

void read_function()
{
    system("/bin/sh");
}

void create_note(int32_t idx)
{
    char buf[0x408];
    int32_t title_size, content_size;
    char *title, *content;

    // Check if note exist
    if (note[idx])
    {
        puts("Note exist!");
        return;
    }

    // Get title size
    printf("Title size: ");
    scanf("%d", &title_size);
    if (title_size < 0 || title_size > 0x400)
    {
        puts("Invalid size!");
        return;
    }
    title = malloc(title_size+8);
    title_size = (((int64_t*)title)[-1] & 0xfffffffffffffff0) - 0x10;
    note[idx] = title;

    printf("Title: ");
    memset(buf, 0, sizeof(buf));
    read_str(buf, title_size);
    strcpy(note[idx], buf);


    // Get content size
    printf("Content size: ");
    scanf("%d", &content_size);
    if (content_size < 0 || content_size > 0x400)
    {
        puts("Invalid size!");
        memset(title, 0, title_size+8);
        free(title);
        note[idx] = 0;
        return;
    }
    content = malloc(content_size);
    content_size = (((int64_t*)content)[-1] & 0xfffffffffffffff0) - 0x10;
    *(int64_t*)(&note[idx][title_size]) = (int64_t)content;

    printf("Content: ");
    memset(buf, 0, sizeof(buf));
    read_str(buf, content_size);
    strcpy(content, buf);
    puts("Done!\n\n");
}

void edit_title(int32_t idx)
{
    // Do not need to delete
    char buf[0x408];
    int32_t title_size;
    char *title;

    title = note[idx];
    title_size = (((int64_t*)title)[-1] & 0xfffffffffffffff0) - 0x10;
    printf("New title: ");
    memset(buf, 0, sizeof(buf));
    read_str(buf, title_size);
    strcpy(title, buf);
    puts("Done!\n\n");
}

void edit_content(int32_t idx)
{
    // Delete content and create new one
    char buf[0x408];
    int32_t title_size, content_size, input_content_size;
    char *title, *content;

    printf("Content size: ");
    scanf("%d", &input_content_size);
    if (input_content_size < 0 || input_content_size > 0x400)
    {
        puts("Invalid size!");
        return;
    }
    title = note[idx];
    title_size = (((int64_t*)title)[-1] & 0xfffffffffffffff0) - 0x10;
    content = (char*)*(int64_t*)(&note[idx][title_size]);
    content_size = (((int64_t*)content)[-1] & 0xfffffffffffffff0) - 0x10;
    memset(content, 0, content_size);
    free(content);

    content = malloc(input_content_size);
    content_size = (((int64_t*)content)[-1] & 0xfffffffffffffff0) - 0x10;
    *(int64_t*)(&note[idx][title_size]) = (int64_t)content;

    printf("Content: ");
    memset(buf, 0, sizeof(buf));
    read_str(buf, content_size);
    strcpy(content, buf);
    puts("Done!\n\n");
}

void edit_note(int32_t idx)
{
    int32_t choice;

    if (!note[idx])
    {
        puts("Note doesn't exist!");
        return;
    }
    do
    {
        puts("1. Edit title");
        puts("2. Edit content");
        puts("3. Back");
        printf("> ");
        scanf("%d", &choice);
        if (choice==1)
            edit_title(idx);
        else if (choice==2)
            edit_content(idx);
    }while (choice!=3);
}

void view_note(int32_t idx)
{
    char buf[0x408];
    int32_t title_size, content_size;
    char *title, *content;

    if (!note[idx])
    {
        puts("Note doesn't exist!");
        return;
    }

    title = note[idx];
    title_size = (((int64_t*)title)[-1] & 0xfffffffffffffff0) - 0x10;
    strcpy(buf, title);
    printf("Title: %s\n", title);

    content = (char*)*(int64_t*)(&note[idx][title_size]);
    content_size = (((int64_t*)content)[-1] & 0xfffffffffffffff0) - 0x10;
    strcpy(buf, content);
    printf("Content: %s\n", content);
}

void delete_note(int32_t idx)
{
    int32_t title_size, content_size;
    char *title, *content;

    if (!note[idx])
    {
        puts("Note doesn't exist!");
        return;
    }

    title = note[idx];
    title_size = (((int64_t*)title)[-1] & 0xfffffffffffffff0) - 0x10;
    content = (char*)*(int64_t*)(&note[idx][title_size]);
    content_size = (((int64_t*)content)[-1] & 0xfffffffffffffff0) - 0x10;

    memset(content, 0, content_size);
    free(content);
    memset(title, 0, title_size+8);
    free(title);

    note[idx] = 0;
    puts("Done!\n\n");
}

int main()
{
    int32_t choice, idx, is_done = 0;

    init();
    while (!is_done)
    {
        menu();
        scanf("%d", &choice);


        if (choice<5)
        {
            printf("Index: ");
            scanf("%d", &idx);
            if (idx < 0 || idx > 7)
            {
                puts("Invalid index!");
                continue;
            }
        }

        switch(choice)
        {
        case 1:
            create_note(idx);
            break;
        case 2:
            edit_note(idx);
            break;
        case 3:
            view_note(idx);
            break;
        case 4:
            delete_note(idx);
            break;
        case 5:
            is_done = 1;
            break;
        default:
            puts("Invalid choice!");
        }
    }
}