### Public
Name: Not a Note
Description: I created a note keeper and I'm going to deploy to the public world but not sure if it's safe to protect my server, could you give it a try to see if it's vulnerable or not? Thanks in advanced!

### Private
- docker: dùng để build và chạy docker trên server
- player: các file trong thư mục này được chia sẻ cho người chơi
- solution: chứa source và solve script