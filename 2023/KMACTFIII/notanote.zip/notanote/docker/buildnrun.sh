#!/bin/sh

docker build . -t notanote && docker run -d --rm -p 10001:10001 -it notanote