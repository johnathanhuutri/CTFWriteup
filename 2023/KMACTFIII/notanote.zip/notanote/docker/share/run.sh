#!/bin/sh

cd /app
socat tcp-listen:10001,fork,reuseaddr exec:./notanote