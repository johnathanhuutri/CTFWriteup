### Public
Name: Password Manager
Description: 'cause I have a hundred of credential and I cannot remember them by my own, I decided to make this program and make it online to help me access those critical credentials. Could you verify that this program is unexploitable?

### Private
- docker: dùng để build và chạy docker trên server
- player: các file trong thư mục này được chia sẻ cho người chơi
- solution: chứa source và solve script