#!/bin/sh

gcc passwordmanager.c -o passwordmanager
cp passwordmanager ../player
cp passwordmanager ../docker/share

