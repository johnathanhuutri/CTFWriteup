#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>


int64_t *canary = 0;
int64_t canary_count = -1;
int32_t encrypted = 0;
int32_t note_size[4];
char note[4][0x100];
char key[0x8];

void init()
{
    int fd;

    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);

    fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0)
    {
        puts("Cannot open /dev/urandom!");
        exit(0);
    }
    read(fd, key, 8);
    close(fd);
}

void gen_canary()
{
    int32_t fd;

    canary = realloc(canary, (++canary_count + 1)*8);
    fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0)
    {
        puts("Cannot open /dev/urandom!");
        exit(0);
    }
    read(fd, &canary[canary_count], 8);
    close(fd);
}

void set_canary(char *buf, int64_t buf_size)
{
    int64_t *can;

    gen_canary();
    can = (int64_t*)&buf[buf_size-8];
    *can = canary[canary_count];
}

void check_canary(char *buf, int64_t buf_size)
{
    int64_t *can;
    int8_t res = 0;

    can = (int64_t*)&buf[buf_size-8];
    for (int32_t i=0; i<=canary_count; i++)
        if (*can==canary[i])
            res = 1;
    if (!res)
    {
        puts("*** stack smashing detected ***: terminated");
        puts("Aborted");
        exit(0);
    }
}

void menu()
{
    puts("--------------------------");
    puts("|    Password manager    |");
    puts("--------------------------");
    puts("1. New credential");
    puts("2. Edit credential");
    puts("3. Delete credential");
    if (encrypted)
        puts("4. Decrypt");
    else
        puts("4. Encrypt");
    puts("5. Exit");
    printf("> ");
}

void lock_n_lock(int32_t idx)
{
    char buf[0x100 + 8];

    memset(buf, 0, sizeof(buf));
    set_canary(buf, sizeof(buf));

    if (idx!=-1)
    {
        for (int i=0; i<note_size[idx]; i++)
            buf[i] = note[idx][i] ^ key[i % 8];
        memcpy(note[idx], buf, note_size[idx]);
        return;        
    }

    for (int n=0; n<4; n++)
    {
        if (encrypted)
            printf("Encrypting credential %d...", n);
        else
            printf("Decrypting credential %d...", n);
        memset(buf, 0, 0x100);
        for (int i=0; i<note_size[n]; i++)
            buf[i] = note[n][i] ^ key[i % 8];
        memcpy(note[n], buf, note_size[n]);
        puts("\t--> Done");
    }

    check_canary(buf, sizeof(buf));
}

void add_cred(int32_t idx)
{
    // size, read_size, canary
    char buf[8 + 8 + 8];

    memset(buf, 0, sizeof(buf));
    set_canary(buf, sizeof(buf));

    if (note_size[idx]!=0)
    {
        puts("Note exist!");
        return;
    }

    printf("Size: ");
    scanf("%lu", (int64_t*)&buf[0]);
    getchar();

    *(int64_t*)&note_size[idx] = *(int64_t*)&buf[0];
    if (note_size[idx] <= 0 || note_size[idx] > 0x100)
    {
        puts("Invalid size!");
        note_size[idx] = 0;
        return;
    }
    printf("Data: ");
    *(int64_t*)&buf[8] = read(0, note[idx], note_size[idx]);
    if (note[idx][*(int64_t*)&buf[8]-1] == '\n')
        note[idx][*(int64_t*)&buf[8]-1] = '\0';
    if (encrypted)
    {
        printf("Encrypting credential...");
        lock_n_lock(idx);
        puts("\t--> Done");
    }

    check_canary(buf, sizeof(buf));
}

void edit_cred(int32_t idx)
{
    // buf, choice, read_size, canary
    char buf[0x100 + 8 + 8 + 8];

    memset(buf, 0, sizeof(buf));
    set_canary(buf, sizeof(buf));

    if (note_size[idx]==0)
    {
        puts("Note doesn't exist!");
        return;
    }

    if (encrypted)
    {
        printf("Decrypting credential...");
        lock_n_lock(idx);
        puts("\t--> Done");
    }
    printf("Old data: %s\n", note[idx]);
    printf("New data: ");
    *(int64_t*)&buf[0x100 + 8] = read(0, buf, 0x100);
    if (buf[*(int64_t*)&buf[0x100 + 8]-1] == '\n')
        buf[*(int64_t*)&buf[0x100 + 8]-1] = '\0';

    printf("Save note? [y/n]: ");
    scanf("%c", &buf[0x100]);
    getchar();
    if (buf[0x100]=='y')
    {
        if (strlen(buf) > note_size[idx])
            note_size[idx] = strlen(buf);
        memcpy(note[idx], buf, note_size[idx]);
        puts("Done!");
    }
    if (encrypted)
    {
        printf("Encrypting credential...");
        lock_n_lock(idx);
        puts("\t--> Done");
    }

    check_canary(buf, sizeof(buf));
}

void delete_cred(int32_t idx)
{
    char buf[8 + 8];

    memset(buf, 0, sizeof(buf));
    set_canary(buf, sizeof(buf));

    if (note_size[idx]==0)
    {
        puts("Note doesn't exist!");
        return;
    }

    if (encrypted)
    {
        printf("Decrypting credential...");
        lock_n_lock(idx);
        puts("\t--> Done");
    }
    printf("Data: %s\n", note[idx]);
    if (encrypted)
    {
        printf("Encrypting credential...");
        lock_n_lock(idx);
        puts("\t--> Done");
    }

    printf("Delete note? [y/n]: ");
    scanf("%c", &buf[0]);
    getchar();
    if (buf[0]=='y')
    {
        memset(note[idx], 0, note_size[idx]);
        note_size[idx] = 0;
        puts("Done!");
    }

    check_canary(buf, sizeof(buf));
}

int main()
{
    // choice, idx, is_done, canary
    char buf[8 + 8 + 8 + 8];

    *(int64_t*)&buf[8 + 8] = 0;
    int32_t choice, idx, is_done = 0;

    init();
    memset(buf, 0, sizeof(buf));
    set_canary(buf, sizeof(buf));

    while (!*(int64_t*)&buf[8 + 8])
    {
        menu();
        scanf("%d", (int32_t*)&buf[0]);
        getchar();

        if (*(int32_t*)&buf[0] != 5 && *(int32_t*)&buf[0] != 4)
        {
            printf("Index: ");
            scanf("%d", (int32_t*)&buf[8]);
            getchar();
            if (*(int32_t*)&buf[8] < 0 || *(int32_t*)&buf[8] >= 4)
            {
                puts("Invalid index!");
                continue;
            }
        }

        switch(*(int32_t*)&buf[0])
        {
        case 1:
            add_cred(*(int32_t*)&buf[8]);
            break;
        case 2:
            edit_cred(*(int32_t*)&buf[8]);
            break;
        case 3:
            delete_cred(*(int32_t*)&buf[8]);
            break;
        case 4:
            if (encrypted)
                encrypted = 0;
            else
                encrypted = 1;
            lock_n_lock(-1);
            break;
        case 5:
            *(int64_t*)&buf[8 + 8] = 1;
            break;
        default:
            puts("Invalid choice!");
        }
    }
    check_canary(buf, sizeof(buf));
}