#!/bin/sh

cd /app
socat tcp-listen:10002,fork,reuseaddr exec:./passwordmanager