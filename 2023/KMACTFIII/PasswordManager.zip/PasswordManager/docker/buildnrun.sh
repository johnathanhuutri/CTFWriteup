#!/bin/sh

docker build . -t passwordmanager && docker run -d --rm -p 10002:10002 -it passwordmanager