### Public
Name: KMAWeb
Description: I created a website for my club and I bet you can get the root flag which is at "/root/root.txt" . Don't let me down with your skill!!!

P/s: Install dependency `Flask` with pip3 then run `python3 run.py`

### Private
- docker: dùng để build và chạy docker trên server
- player: các file trong thư mục này được chia sẻ cho người chơi
- solution: chứa source và solve script