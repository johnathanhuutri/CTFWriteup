Challenge name: Racecar
Description:
```
Do you want to race?
```

### Chú thích
Thư mục player là các file đó sẽ được public cho người chơi
Thư mục docker có script buildnrun.sh dùng để build và chạy docker
Thư mục solution chứa mã nguồn và solve script

### Dữ liệu dưới đây sẽ không được công khai chung vs chall
Hint 1: Race condition
Hint 2: Race nhiều lần sẽ thấy