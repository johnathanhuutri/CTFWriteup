#!/bin/sh

gcc -fno-stack-protector solution/pwncry.c -o pwncry -lm
cp pwncry player
cp pwncry docker/share