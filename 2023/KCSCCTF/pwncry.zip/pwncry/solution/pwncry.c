#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <sys/socket.h>
#include <sys/mman.h>

#define PORT 8888

int connect_to_server()
{
	struct sockaddr_in serv_addr;
	int client_fd, status;

    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        return -1;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
  
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0)
        return -1;

    if (connect(client_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
        return -1;
    return client_fd;
}

/*----------------- CRYPTO FUNCTIONS -----------------*/
char *n, *e;
void gen_key()
{
	char buffer[0x100];
	int sock_fd;
	char *p;

	memset(buffer, 0, sizeof(buffer));
	sock_fd = connect_to_server();
	if (sock_fd==-1)
	{
		puts("[-] Cannot connect to encryption server!");
		exit(0);
	}
    send(sock_fd, "<START>GENKEY<END>", 18, 0);
    read(sock_fd, buffer, 1024);
    close(sock_fd);

    n = &buffer[7];
    e = strstr(n, "-");
    e[0] = '\0';
    e = &e[1];
    *strstr(e, "<END>") = '\0';

    n = strdup(n);
    e = strdup(e);
	printf("RSA publickey: (n, e) = (%s, %s)\n", n, e);

}
unsigned long int encrypt(unsigned long int k)
{
	char buffer[0x100];

	memset(buffer, 0, sizeof(buffer));
	snprintf(buffer, 0x100, "<START>ENCRYPT-%lu-%s-%s<END>", k, e, n);

	int sock_fd = connect_to_server();
	if (sock_fd==-1)
	{
		puts("[-] Cannot connect to encryption server!");
		exit(0);
	}
    send(sock_fd, buffer, strlen(buffer), 0);
	memset(buffer, 0, sizeof(buffer));
    read(sock_fd, buffer, 0x100);
  
    close(sock_fd);
	return strtoul(&buffer[7], NULL, 10);
}
/*--------------- END CRYPTO FUNCTIONS ---------------*/


void init()
{
	setbuf(stdin, 0);
	setbuf(stdout, 0);
	setbuf(stderr, 0);
}

void menu()
{
	puts("----------- MENU -----------");
	puts("1. Add credential");
	puts("2. Show credential");
	puts("3. Exit");
	printf("> ");
}

unsigned long int *database[0x10];
unsigned int data_length[0x10];
void add_cred(char *buffer, unsigned int length)
{
	unsigned int idx, i;
	unsigned long int *p;
	for (idx=0; idx<100 && database[idx]; idx++);

	if (length % 8 == 0)
		data_length[idx] = length / 8;
	else if (length > 0x400-8)
		data_length[idx] = 0x400 / 8;
	else
		data_length[idx] = (length / 8) + 1;
	database[idx] = malloc(data_length[idx] * 8);
	p = (unsigned long int *)buffer;
	for (i=0; i<data_length[idx]; i++)
		database[idx][i] = encrypt(p[i]);
}

void show_cred()
{
	puts("----- SAVED CREDENTIAL -----");
	for (unsigned int idx=0; idx<0x10; idx++)
	{
		if (database[idx])
		{
			printf("Cred %u: ", idx+1);
			for (unsigned int i=0; i<data_length[idx]; i++)
				printf("%lu ", database[idx][i]);
			puts("");
		}
	}
}

void gen_gadget()
{
	int fd, seed;
	unsigned long int addr;
	char *gadget[5];

	fd = open("/dev/urandom", 0, 0);
	read(fd, &seed, 4);
	srand(seed);

	for (unsigned int i=0; i<5; i++)
	{
		read(fd, &addr, 6);
		addr = addr >> 4;
		addr &= 0xfffffffffffff000;
		gadget[i] = mmap((void*)addr, 0x1000, PROT_NONE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	}

	for (unsigned int i=0; i<5; i++)
	{
		mprotect(gadget[i], 0x1000, 2);
		if (i==0)
		{
			addr = rand() % 0xff0;
			gadget[i][addr] = '\xb0';
			gadget[i][addr + 1] = '\x0a';
			gadget[i][addr + 2] = '\xc3';
		}
		else if (i==1)
		{
			addr = rand() % 0xff0;
			gadget[i][addr] = '\x5f';
			gadget[i][addr + 1] = '\xc3';
		}
		else if (i==2)
		{
			addr = rand() % 0xff0;
			gadget[i][addr] = '\x5e';
			gadget[i][addr + 1] = '\xc3';
		}
		else if (i==3)
		{
			addr = rand() % 0xff0;
			gadget[i][addr] = '\x5a';
			gadget[i][addr + 1] = '\xc3';
		}
		else if (i==4)
		{
			addr = rand() % 0xff0;
			gadget[i][addr] = '\x0f';
			gadget[i][addr + 1] = '\x05';
			gadget[i][addr + 2] = '\xc3';
		}
		mprotect(gadget[i], 0x1000, 5);
		gadget[i] = gadget[i] + addr;
		add_cred((char*)&gadget[i], 6);
	}

	close(fd);
}

int main()
{
	unsigned int option, done = 0, length;
	char buffer[0x400];

	init();

	puts("_______________ PWNCRY _______________");
	puts("           Password Manager\n");

	gen_key();
	gen_gadget();
	while (!done)
	{
		menu();
		scanf("%d", &option);
		getchar();
		if (option==1)
		{
			puts("New credential (format: \"[username]:[password]\")");
			printf("> ");
			memset(buffer, 0, sizeof(buffer));
			scanf("%s", buffer);
			length = strlen(buffer);
			add_cred(buffer, length);
			puts("Done!");
		}
		else if (option==2)
			show_cred();
		else if (option==3)
			break;
		else
			puts("Invalid choice!");
	}
	__asm__(
		".intel_syntax noprefix;"
		"xor rax, rax;"
		"xor rbx, rbx;"
		"xor rcx, rcx;"
		"xor rdx, rdx;"
		"xor rsi, rsi;"
		"xor rdi, rdi;"
		"xor r8, r8;"
		"xor r9, r9;"
		"xor r10, r10;"
		"xor r11, r11;"
		"xor r12, r12;"
		"xor r13, r13;"
		"xor r14, r14;"
		"xor r15, r15;"
		".att_syntax;"
		);
	return 0;
}