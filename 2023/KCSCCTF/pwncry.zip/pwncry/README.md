Challenge name: pwncry
Description:
```
I created this password manager named pwncry. Will you try or will you cry?
```

### Chú thích
Thư mục player là các file đó sẽ được public cho người chơi
Thư mục docker dùng để build và chạy docker. Chạy file `buildnrun.sh` trong thư mục docker để build và chạy.
Thư mục solution chứa mã nguồn và solve script

### Hints
Hint 1: mprotect() again
Hint 2: Check return value of mprotect()