#!/bin/sh

sudo docker-compose up --build