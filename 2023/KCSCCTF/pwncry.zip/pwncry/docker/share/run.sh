#!/bin/sh

cd /home/user
./encryption_server.py &
socat tcp-listen:10003,fork,reuseaddr exec:./pwncry 2>/dev/null