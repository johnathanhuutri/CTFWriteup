#!/bin/sh

socat tcp-listen:9991,fork,reuseaddr exec:./convert 2>/dev/null